export const link = "https://ecommercev01.pythonanywhere.com";
